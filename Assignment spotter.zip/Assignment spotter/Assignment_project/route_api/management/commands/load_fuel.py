import csv
from django.core.management.base import BaseCommand
from route_api.models import FuelStation



# import csv file to FuelStation model (database)

class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        
        with open('./example_fuel_prices.csv', 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                FuelStation.objects.create(
                    name=row['Name'],
                    address=row['Address'],
                    city=row['City'],
                    state=row['State'],
                    latitude=float(row['Latitude']),
                    longitude=float(row['Longitude']),
                    price_per_gallon=float(row['Price_per_gallon'])
                )
        self.stdout.write(self.style.SUCCESS('Données chargées !'))