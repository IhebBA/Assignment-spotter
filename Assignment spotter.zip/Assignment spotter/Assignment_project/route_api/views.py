from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response

import requests
import folium
import polyline
from .models import FuelStation


def get_fuel_route(start_loc, end_loc):
    # 1. Géocodage (Ville -> Coordonnées) via Nominatim
    def get_coords(loc):
        url = f"https://nominatim.openstreetmap.org/search?q={loc}&format=json&limit=1"
        r = requests.get(url, headers={'User-Agent': 'FuelApp'}).json()
        return (float(r[0]['lat']), float(r[0]['lon']))

    coords_start = get_coords(start_loc)
    coords_end = get_coords(end_loc)

    # 2. Routing via OSRM (1 seul appel)
    route_url = f"http://router.project-osrm.org/route/v1/driving/{coords_start[1]},{coords_start[0]};{coords_end[1]},{coords_end[0]}?overview=full&geometries=polyline"
    route_data = requests.get(route_url).json()
    
    geometry = route_data['routes'][0]['geometry']
    distance_meters = route_data['routes'][0]['distance']
    distance_miles = distance_meters * 0.000621371 # 1 meter aproximation 0.000621371
    
    # Décoder la route pour Folium
    path = polyline.decode(geometry)

    # 3. Logique de Carburant (Simple & Rapide)
    # On prend la station la moins chère du pays pour l'exemple du test
    # (Ou on filtre par État si on veut être plus précis)
    best_station = FuelStation.objects.order_by('price_per_gallon').first()
    
    # Calculs demandés
    # Total Gallons = Distance / 10 MPG
    total_gallons = distance_miles / 10
    total_cost = total_gallons * best_station.price_per_gallon
    
    # 4. Création de la Carte Folium
    m = folium.Map(location=coords_start, zoom_start=5)
    folium.PolyLine(path, color="blue", weight=5).add_to(m)
    
    # Marqueurs
    folium.Marker(coords_start, popup="Start", icon=folium.Icon(color='green')).add_to(m)
    folium.Marker(coords_end, popup="Finish", icon=folium.Icon(color='red')).add_to(m)
    
    # Ajouter des arrêts tous les 450 miles (pour rester sous les 500)
    stops_needed = int(distance_miles // 450)
    for i in range(1, stops_needed + 1):
        # On place l'arrêt approximativement sur le tracé
        idx = int((len(path) / (stops_needed + 1)) * i)
        folium.Marker(
            path[idx], 
            popup=f"Fuel Stop: {best_station.name} (${best_station.price_per_gallon})",
            icon=folium.Icon(color='orange', icon='gas-pump', prefix='fa')
        ).add_to(m)

    

    results = {
        "total_distance_miles": round(distance_miles, 2),
        "total_fuel_cost": round(total_cost, 2),
        "stops": stops_needed,
    }
    
    return results, m

class RouteAPIView(APIView):
    def post(self, request):
        start = request.data.get('start')
        finish = request.data.get('finish')
        
        if not start or not finish:
            return Response({"error": "Please provide a start and finish location"}, status=400)
        
        try:
            # Unpack data and map object
            data, m = get_fuel_route(start, finish)
            
            # Prepare context for template
            context = {
                'mymap': m._repr_html_(),
                'total_distance_miles': data['total_distance_miles'],
                'total_fuel_cost': data['total_fuel_cost'],
                'stops': data['stops']
            }
            return render(request, 'map.html', context)
        except Exception as e:
             return Response({"error": str(e)}, status=500)

        
        
